#!/bin/bash

nukepath=~/.nuke
nukeinit=$nukepath/init.py
panotools=$nukepath/PanoReview

plugins=(
    AssembleReviewer
    LutReview
    UpdateReviewTools
)

files=(
    menu.py
    README.md
    install.sh
    install.bat
    uninstall.sh
    uninstall.bat
)

install() {
    addline="nuke.pluginAddPath('PanoReview')"
    [ -d $panotools ] || mkdir -p $panotools
    for f in ${files[*]}; do [ -f $f ] && cp $f $panotools || continue; done
    for d in ${plugins[*]}; do [ -d $d ] && cp -r $d $panotools || continue; done
    [ -f $nukeinit ] || cp init.py $nukepath

    if grep -Fxq $addline $nukeinit
    then
       echo "Updated PanoReview"
    else
        lines=$(wc -l $nukeinit | awk '{print $1}')
        lines+=i
        sed -i '' "$lines\\
$addline\\
" $nukeinit 
        echo "Installed PanoReview"  
    fi
}

[ ! -d $nukepath ] && echo "$0: could not find .nuke folder" && exit
install

