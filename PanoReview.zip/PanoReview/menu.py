from AssembleReviewer import AssembleReviewer
from LutReview import LutReview
from UpdateReviewTools import UpdateReviewTools

nuke.menu('Nuke').addCommand('PanoTools/Assemble Review', 'AssembleReviewer.AssembleReviewer()')
nuke.menu('Viewer').addCommand('Review Lut', 'LutReview.LutReview()', 'shift+p')
nuke.menu('Nuke').addCommand('PanoTools/Update Review Tools', 'UpdateReviewTools.UpdateReviewTools()')

