# PanoReview

PanoReview-1.0.0

Colección de tools y plugins para Nuke con la finalidad de ayudar los procesos de
revisión en Panolab.

* AssembleReview: arma revisores comparando último render y plate original fácilmente.
* LutReview: cambia selección de luts según nodos conectados al viewer con 'Shift + P'.
* UpdateReviewTools: actualiza el paquete PanoReview con un solo click desde Nuke.

## Shortcuts

* 'Alt + P': cambia la seleccióin de luts según nodos conectados al viewer.

## Instalación

Se puede instalar automáticamente a través de un script de instalación, o manualmente.
Ambas instalaciones hacen exactamente las mismas operaciones en el sistema. Para que
la instalación surta efecto es necesario cerrar todas las instancias de Nuke y volver 
a abrirlo.

Nota: para que algunos de los plugins de este repositorio funcionen correctamente se
debe instalar las PanoTools.

### Instalación Automática

Existen dos scripts de instalación y dos scripts de desinstalación.
Los scripts llamados 'install.bat' y 'uninstall.bat' son exclusivos para Windows, 
mientras que los scripts 'install.sh' y 'uninstall.sh' sirven tanto para MacOS 
como para Linux.

### Instalación Automática en Windows

Para instalar las PanoReview en Windows se puede simplemente hacer doble click en 
el archivo 'install.bat', o bien se puede ejecutar en una consola de comandos desde
la carpeta donde recide este archivo, escribiendo 'install.bat' y presionando
'Enter'. Si se ejecutó haciendo doble click, esto abrirá una terminal donde se
correrán una serie de comandos y luego se cerrará rápidamente. Una vez hecho esto
los archivos y directorios correspondientes quedarán dentro de la carpeta .nuke,
y ya se puede eliminar o hacer lo que se desee con la carpeta de instalación.

Nota: NUNCA CORRER EL INSTALADOR DE WINDOWS COMO ADMINISTRADOR!!

### Instalación Automática en MacOS y Linux

Para instalar las PanoReview en MacOS y Linux se debe abrir una terminal en la
carpeta de instalación, donde reside el archivo 'install.sh'. A diferencia de la
instalación en Windows, el script de instalación de MacOS y Linux se debe correr
desde una terminal. Para ello, se debe abrir una terminal en la ruta donde existe el
script de instalación, y luego correr el siguiente comando..

```shell
./install.sh
```

### Instalación Manual

La instalación manual de las PanoReview es igual para Windows, MacOS y Linux.
Para instalar manualmente las PanoReview hay dos pasos a seguir.

* 1)

Copiar o mover la carpeta correspondiente a las PanoReview dentro de la carpeta 
.nuke en tu sistema. Es muy importante no realizar ningún otro cambio en la 
carpeta y archivos que se están moviendo o copiando.

* 2)

Agregar una línea de código Python en el archivo init.py que existe dentro
de la carpeta .nuke. Si no existe este archivo, puedes copiar el archivo init.py
de este repositorio dentro de la carpeta .nuke y luego editarlo.

Línea a agregar al final de tu archivo init.py:

```Python
nuke.pluginAddPath('PanoReview')
```

Tener en cuenta mayúsculas. Consideración por los símbolos <'> que rodean la ruta,
ya que algunos sistemas pueden cambiarlos automáticamente al copiar y pegar, y
pueden no ser compatibles con la sintaxis de Python.

## Actualizar

Para actualizar tus PanoReview a una nueva versión puedes simplemente correr los
scripts de instalación nuevamente, ellos están pensados para ser usados múltiples
veces sin generar problemas, facilitando la fácil actualización de las herramientas.
Para actualizar manualmente solo se deben copiar las carpetas correspondientes a las
tools en la raíz de la carpeta .nuke sobreescribiéndo las carpetas con los mismos
nombres. Por último, existe la herramiento UpdateTools dentro de las PanoReview, que
te permite actualizar las PanoReview automáticamente desde Nuke, yendo a la barra de
herramientas superior, haciendo click en 'PanoReview' y luego 'Update Tools' en la
lista desplegable.

Para que la actualización surta efecto es necesario cerrar todas las instancias de
Nuke y volver a abrirlo.

## Desinstalación

Los scripts de desinstalación funcionan exactamente igual que los de instalación. En
Windows se puede simplemente hacer doble click en 'uninstall.bat', mientras que en
MacOS y Linux se debe correr el script 'uninstall.sh' desde una terminal, 
específicando si se desean desinstalar todos los plugins, o cuales particularmente,
de la misma forma que se debe hacer con el archivo 'install.sh' para la instalación.

Para desinstalar manualmente, se deben borrar las carpetas correspondientes a las
tools del interior del directorio .nuke. Luego se deben borrar las líneas que hacen
alusión a la herramienta del archivo .nuke/init.py.

Para que la desinstalación surta efecto es necesario cerrar todas las instancias de
Nuke y volver a abrirlo.

## Tools

A continuación hay un listado de las herramientas que incluye este repositorio y lo
que cada una hace. Para acceder a estos plugins puedes presionar el menú 'PanoReview'
presente en la barra de herramientas superior en Nuke.

### AssembleReviewer

PlugIn hecho en Python para nuke con el fin de armar revisores rápida
y fácilmente. Con un directorio donde buscar y una lista de planos por buscar,
es capaz de encontrar la media y el último render sacado de dicho plano para ser
subido a un proyecto de Nuke lado a lado, y poder ser fácilmente revisado en su
version original en comparación con el trabajo realizado en composición.

### LutReview

Herramienta para cambiar archivos luts automáticamente en todos los nodos
OCIOFileTransform automáticamente para revisar planos con distintos luts desde una
misma sesión de Nuke.

### UpdateReviewTools

Herramienta para actualizar todo el conjunto de tools de PanoReview con un solo
click, y sin salir de Nuke.

