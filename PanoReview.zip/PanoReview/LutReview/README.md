# LutReview

Herramienta para cambiar archivos luts automáticamente en todos los nodos
OCIOFileTransform automáticamente para revisar planos con distintos luts desde una
misma sesión de Nuke.

## Instalación

Copiar la carpeta 'LutReview' dentro del directorio .nuke sin realizar ningún
cambio. Además, copiar la siguiente línea de código Python al final del archivo
.nuke/init.py

```python
nuke.pluginAddPath('LutReview')
```

Para que la instalación surta efecto es necesario cerrar todas las instancias de
Nuke y volver a abrir.

