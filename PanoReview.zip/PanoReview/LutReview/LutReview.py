# Written by Eugenio Arteaga at Panolab spa

import nuke
import sys
import os

sys.path.append(os.path.join(os.path.expanduser('~'), '.nuke', 'PanoTools', 'PanoModules'))
import requests

def download_file(url, path):
    with requests.get(url, stream=True) as r:
        r.raise_for_status()
        with open(path, 'wb') as f:
            for chunk in r.iter_content(chunk_size=8192): 
                f.write(chunk)

def lut_get(path, lutname):
    url = 'https://raw.githubusercontent.com/Panolab/BBLuts/main/BBLuts'
    difstrs = {
        'BB_102_0170', 'BB_102_0180', 'BB_102_0190', 'BB_102_0380', 'BB_102_0400',
        'BB_102_0410', 'BB_102_0420', 'BB_102_0430', 'BB_102_0440', 'BB_102_0450',
        'BB_102_0460', 'BB_102_0470', 'BB_102_0490', 'BB_102_0500', 'BB_102_0510', 
        'BB_102_0520', 'BB_102_0530'
    }

    dif = False
    if lutname in difstrs:
        url += '2'
        dif = True

    lutname += '_LUT.cube' if dif == False else '_COLOR_ACEScct-R709.cube'
    luturl = url + '/' + lutname
    lutpath = os.path.join(path, lutname)
    if not os.path.exists(lutpath):
        download_file(luturl, lutpath)

    nodes = nuke.allNodes(recurseGroups=True)
    for n in nodes:
        if n.Class() == 'OCIOFileTransform':
            n['file'].setValue(lutpath.replace('\\', '/'))
        if n.Class() == 'OCIOColorSpace':
            n['disable'].setValue(dif)

def LutReview():
    scriptdir = nuke.script_directory()
    if not scriptdir or len(scriptdir) == 0:
        nuke.message('It seems you have not saved your script yet')
        return

    path = os.path.join(os.path.dirname(scriptdir), 'ASSETS', 'LUTS')
    if not os.path.exists(path):
        os.makedirs(path)

    vwindow = nuke.activeViewer()
    if vwindow == None:
        nuke.message('There is no active viewer node')
        return

    viewer = vwindow.node()
    connections = viewer.inputs()
    for i in range(connections):
        node = viewer.input(i)
        if node != None and node.Class() == 'Read':
            filename = os.path.basename(nuke.filename(node))
            lut_get(path, '_'.join(filename.split('_')[:3]))
            break

