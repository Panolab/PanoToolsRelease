import LutReview
nuke.menu('Viewer').addCommand('Review Lut', 'LutReview.LutReview()', 'shift+p')
