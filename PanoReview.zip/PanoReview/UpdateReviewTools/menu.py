import UpdateReviewTools
nuke.menu('Nuke').addCommand('PanoTools/Update Review Tools', 'UpdateReviewTools.UpdateReviewTools()')
