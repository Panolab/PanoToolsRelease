import nuke

nuke.pluginAddPath('PanoReview')

