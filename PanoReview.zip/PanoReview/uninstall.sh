#!/bin/bash

nukepath=~/.nuke
nukeinit=$nukepath/init.py
panotools=$nukepath/PanoReview

uninstall() {
    [ -d $panotools ] && rm -r $panotools || echo "Could not find '$panotools'"
    [ ! -f $nukeinit ] && echo "Missing $nukeinit file" && return
    sed -i '' -e '/nuke.pluginAddPath(/!b' -e "/PanoReview/d" $nukeinit
    echo "Uninstalled PanoReview"
}

[ ! -d $nukepath ] && echo "$0: could not find .nuke folder" && exit
uninstall

