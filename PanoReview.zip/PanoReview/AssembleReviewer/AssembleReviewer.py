# Written by Eugenio Arteaga A. at Panolab spa.

import os
import nuke
import nukescripts

rangemax = 0

class RevisorAssemblerPanel(nukescripts.PythonPanel):
    def __init__(self):
        nukescripts.PythonPanel.__init__(self, 'Revisor Assembler')
        self.fileKnob = nuke.File_Knob('Search directory:')
        self.textKnob = nuke.Multiline_Eval_String_Knob('Shots to search:')
        self.addKnob(self.fileKnob)
        self.addKnob(self.textKnob)

def getsubpath(dpath, folder):
    subpath = os.path.join(dpath, folder)
    if not os.path.exists(subpath):
        nuke.message('Could not find path ' + subpath)
    return subpath

def getexrpath(dpath):
    exrs = os.listdir(dpath)
    exr = exrs[0]
    exrname = exr[:exr.rfind('_')]
    exrframes = exr[exr.rfind('_') + 1:]
    exrframes = exrframes[:-4]
    exrpad = exrname + '_'
    for i in range(len(exrframes)):
        exrpad = exrpad + '#'
    exrpad = exrpad + '.exr ' + str(int(exrframes)) + '-' + str(int(exrframes) + len(exrs) - 1)
    return os.path.join(dpath, exrpad)

def create_read_node(fname):
    global rangemax
    parts = fname.split(' ')
    exrname = parts[0]
    frange = parts[1]
    rangeparts = frange.split('-')
    first = int(rangeparts[0])
    last = int(rangeparts[1])
    dif = last - first
    if dif > rangemax:
        rangemax = dif

    r = nuke.nodes.Read(file=exrname)
    r['first'].setValue(first)
    r['last'].setValue(last)
    r['origfirst'].setValue(first)
    r['origlast'].setValue(last)
    if first != 1001:
        r['frame_mode'].setValue('start at')
        r['frame'].setValue('1001')
    return r

def create_backdrop(name):
    bd = nukescripts.autoBackdrop()
    bd.setName(name, uncollide=True)
    bd.setYpos(int(bd.ypos()) + 65)
    bd['xpos'].setValue(int(bd['xpos'].getValue()) - 20)
    bd['bdwidth'].setValue(int(bd['bdwidth'].getValue()) + 40)
    bd['bdheight'].setValue(int(bd['bdheight'].getValue()) + 20)
    return bd

def create_backdrop_secuence(currsec, secnodes):
    for node in secnodes:
        node['selected'].setValue(True)
    sbd = create_backdrop(currsec)
    sbd['bdwidth'].setValue(int(sbd['bdwidth'].getValue()) + 30)
    sbd['bdheight'].setValue(int(sbd['bdheight'].getValue()) + 20)
    return sbd

def assemble_reviser(dpath, shots):
    
    if len(dpath) == 0:
        nuke.message("Search directory field cannot be empty")
        return

    if len(shots) == 0:
        nuke.message("Shot list field cannot be empty")
        return

    if not os.path.exists(dpath):
        nuke.message("Search directory (" + dpath + ") does not exist")
        return

    mediapath = getsubpath(dpath, 'MEDIA')
    if not os.path.exists(mediapath): return
    renderpath = getsubpath(dpath, 'SECUENCIAS')
    if not os.path.exists(renderpath): return

    x = 0
    currsec = ''
    secnodes = []

    for shot in shots:
        if len(shot) == 0: continue
        
        parts = shot.split('_')
        if len(parts) < 3:
            nuke.message("Shot (" + shot + ") is missing project, secuence or shot number")
            continue

        project = parts[0]
        secuence = parts[1]
        shotnum = parts[2]
        projsec = parts[0] + '_' + parts[1]

        if len(currsec) == 0:
            currsec = secuence
        elif currsec != secuence:
            create_backdrop_secuence(currsec, secnodes)
            currsec = secuence
            secnodes.clear()
            x += 100

        mediasecpath = getsubpath(mediapath, projsec)
        if not os.path.exists(mediasecpath): continue
        mediashotpath = getsubpath(mediasecpath, shot)
        if not os.path.exists(mediashotpath): continue
        mexrpath = getexrpath(mediashotpath)
        r1 = create_read_node(mexrpath)
        xpos = x
        ypos = r1.ypos()
        r1.setXpos(xpos)

        rendersecpath = getsubpath(renderpath, projsec)
        if not os.path.exists(rendersecpath): continue
        rendersecpath = getsubpath(rendersecpath, shot)
        if not os.path.exists(rendersecpath): continue
        rendersecpath = getsubpath(rendersecpath, 'RENDERS')
        if not os.path.exists(rendersecpath): continue
        rendersecpath = getsubpath(rendersecpath, 'EXR')
        if not os.path.exists(rendersecpath): continue
        renderdirs = os.listdir(rendersecpath)
        rendersecpath = getsubpath(rendersecpath, renderdirs[-1])
        rexrpath = getexrpath(rendersecpath)
        r2 = create_read_node(rexrpath)
        r2.setXYpos(xpos, ypos + 150)

        for node in nuke.selectedNodes():
            node['selected'].setValue(False)

        r1.setSelected(True)
        r2.setSelected(True)
        bd = create_backdrop(shot)
        secnodes.append(bd)
        r1.setYpos(ypos + 20)
        x += 150
    
    sbd = create_backdrop_secuence(currsec, secnodes)
    xmax = x + int(sbd['bdwidth'].getValue()) - 150
    ymax = int(sbd['ypos'].getValue()) + int(sbd['bdheight'].getValue())
    
    viewer = None
    for node in nuke.allNodes():
        if node.Class() == 'Viewer':
            viewer = node
            break
    if viewer == None:
        viewer = nuke.createNode('Viewer')
    viewer.setXYpos(int(xmax / 2), ymax + 150)

def AssembleReviewer():
    panel = RevisorAssemblerPanel()
    if panel.showModalDialog():
        root = nuke.root()
        root['first_frame'].setValue(1001)
        root['format'].setValue('UHD_4K')
        root.setFrame(1001)
    
        fpath = panel.fileKnob.value().strip()
        shotlist = sorted(panel.textKnob.value().splitlines())
        for i in range(len(shotlist)):
            shotlist[i] = shotlist[i].strip()
        assemble_reviser(fpath, shotlist)
    
        root['last_frame'].setValue(1001 + rangemax)
        nuke.zoom(1, nuke.center())
