# AssembleReviewer

PlugIn hecho en Python para nuke con el fin de armar revisores rápida
y fácilmente. Con un directorio donde buscar y una lista de planos por buscar,
es capaz de encontrar la media y el último render sacado de dicho plano para ser
subido a un proyecto de Nuke lado a lado, y poder ser fácilmente revisado en su
version original en comparación con el trabajo realizado en composición.

## Instalación

Copiar la carpeta 'AssembleReviewer' dentro del directorio .nuke sin realizar ningún
cambio. Además, copiar la siguiente línea de código Python al final del archivo
.nuke/init.py

```python
nuke.pluginAddPath('AssembleReviewer')
```

Para que la instalación surta efecto es necesario cerrar todas las instancias de
Nuke y volver a abrir.

