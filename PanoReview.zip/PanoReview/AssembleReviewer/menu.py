import AssembleReviewer
nuke.menu('Nuke').addCommand('PanoTools/Assemble Reviewer', "AssembleReviewer.AssembleReviewer()")
