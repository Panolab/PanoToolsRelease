# Written by Eugenio Arteaga at Panolab spa

import nuke
import nukescripts
import os
import sys

FKEY = '.ftrack_key'
FSERVER = 'https://panolab.ftrackapp.com'
HOMEPATH = os.path.expanduser('~')
NUKEPATH = os.path.join(HOMEPATH, '.nuke')

sys.path.append(os.path.join(NUKEPATH, 'PanoTools', 'PanoModules'))
import ftrack_api

class TaskChooserPanel(nukescripts.PythonPanel):
    def __init__(self, shotname, tasks):
        nukescripts.PythonPanel.__init__(self, 'Task Chooser')
        selected = None
        tasknames = []
        for task in tasks:
            taskname = task['name']
            tasknames.append(taskname)
            if 'Compositing' in taskname:
                selected = taskname
        self.taskKnob = nuke.Enumeration_Knob('tasks', 'Tasks:', tasknames)
        if selected != None:
            self.taskKnob.setValue(selected)
        self.textKnob = nuke.Text_Knob('text', shotname)
        self.addKnob(self.textKnob)
        self.addKnob(self.taskKnob)

class AssetChooserPanel(nukescripts.PythonPanel):
    def __init__(self, shotname, assets):
        nukescripts.PythonPanel.__init__(self, 'Asset Chooser')
        found = False
        self.assetKnob, selected = None, None
        self.textKnob = nuke.Text_Knob('text', shotname)
        self.newKnob = nuke.String_Knob('create asset', 'Create asset:')
        self.addKnob(self.textKnob)
        self.addKnob(self.newKnob)
        if len(assets) > 0:
            assetnames = []
            for asset in assets:
                version = asset['latest_version']
                vernum = 'v{:03d}'.format(version['version']) if version else 'v001'
                assetname = asset['name'] + ' ' + vernum
                assetnames.append(assetname)
                if found == False:
                    lowname = assetname.lower()
                    if '_cmp' in lowname:
                        selected = assetname
                    if '_plab' in lowname:
                        found = True
            self.assetKnob = nuke.Enumeration_Knob('assets', 'Assets:', assetnames)
            self.assetKnob.setValue(selected)
            self.addKnob(self.assetKnob)

class FkeyPanel(nukescripts.PythonPanel):
    def __init__(self):
        nukescripts.PythonPanel.__init__(self, 'Ftrack Key')
        self.mailKnob = nuke.String_Knob('mail', 'Mail:')
        self.keyKnob = nuke.String_Knob('key', 'Ftrack Key:')
        self.addKnob(self.mailKnob)
        self.addKnob(self.keyKnob)

def write_fkey_file(path, mail, fkey):
    file = open(path, 'w')
    file.writelines([mail + '\n', fkey])
    file.close()

def read_fkey_file(path):
    with open(path) as file:
        lines = [line.rstrip() for line in file]
    return lines

def ftrack_connect():
    fkey_path = os.path.join(NUKEPATH, FKEY)
    while not os.path.exists(fkey_path):
        panel = FkeyPanel()
        if panel.showModalDialog():
            mail = panel.mailKnob.value().strip()
            fkey = panel.keyKnob.value().strip()
            write_fkey_file(fkey_path, mail, fkey)
        else: return None
    fkey_lines = read_fkey_file(fkey_path)
    mail = fkey_lines[0]
    fkey = fkey_lines[1]
    try: session = ftrack_api.Session(server_url=FSERVER, api_key=fkey, api_user=mail)
    except: session = None
    return session

def find_mov_recursive(pdir, name):
    dirs = os.listdir(pdir)
    for d in dirs:
        dpath = os.path.join(pdir, d)
        if not os.path.isdir(dpath):
            if d == name + '.mov' or d == name + '.MOV':
                return dpath
        else:
            ret = find_mov_recursive(dpath, name)
            if ret and len(ret) != 0:
                return ret
    return ''

def find_mov(scriptname):
    fdir, fname = os.path.split(scriptname)
    return find_mov_recursive(os.path.dirname(fdir), os.path.splitext(fname)[0])

def session_attach_script(session, task, location, scriptname):
    user = session.query('User where username is "{}"'.format(session.api_user)).one()
    note = task.create_note('Adjunto proyecto:', author=user)
    name = os.path.splitext(os.path.basename(scriptname))[0]
    component = session.create_component(
        scriptname, data={'name': name}, location=location
    )

    session.create('NoteComponent', {
        'component_id': component['id'],
        'note_id': note['id']
    })
    session.commit()

def session_upload_media(session, asset, tasknode, location, movpath):
    asset_version = session.create('AssetVersion', {
        'asset': asset,
        'task': tasknode
    })
    session.commit()

    name = os.path.splitext(os.path.basename(movpath))[0]
    asset_version.create_component(movpath, data={'name': name}, location=location)
    session.commit()

    job = asset_version.encode_media(movpath)
    session.commit()

def PublishVersion():
    try:
        scriptname = nuke.scriptName()
    except:
        nuke.message('It seems you have not saved your script yet')
        return

    movpath = find_mov(scriptname)
    if not movpath or len(movpath) == 0:
        nuke.message(
            'Could not find .mov file with the same name and version of this project: '
            + os.path.splitext(os.path.basename(scriptname))[0]
        )
        return

    session = ftrack_connect()
    if session == None:
        nuke.message('Could not connect to Ftrack')
        return

    shotname = '_'.join(os.path.basename(scriptname).split('_')[:3])
    try:
        shot = session.query('Shot where name like "{}%"'.format(shotname)).one()
    except:
        nuke.message('Could not find shot in Ftrack with name: ' + shotname)
        session.close()
        return

    tasks = []
    for child in shot['children']:
        if isinstance(child, session.types['Task']):
            tasks.append(child)

    if len(tasks) == 0:
        nuke.message('No tasks where found for shot {} in Ftrack'.format(shotname))
        session.close()
        return
    
    panel = TaskChooserPanel(shotname, tasks)
    if panel.showModalDialog():
        taskname = panel.taskKnob.value()
        tasknode = None
        for task in tasks:
            if task['name'] == taskname:
                tasknode = task
                break

        if tasknode == None:
            nuke.message(
                'Could not find task "{}" for shot "{}" in Ftrack'
                .format(taskname, shotname)
            )
            session.close()
            return

        assets = session.query('Asset where name like "{}%"'.format(shotname))
        panel = AssetChooserPanel(shotname, assets)
        if not panel.showModalDialog():
            session.close()
            return

        assetname = panel.newKnob.value().strip()
        if len(assetname) > 0:
            asset_type = session.query('AssetType where name is "Upload"').one()
            asset = session.create('Asset', {
                'name': assetname,
                'type': asset_type,
                'parent': tasknode['parent']
            })
            session.commit()
        elif panel.assetKnob == None:
            nuke.message('Missing name to create and upload new asset')
            session.close()
            return
        else:
            assetname, assetversion = panel.assetKnob.value().split(' ')
            scriptversion = os.path.splitext(os.path.basename(scriptname))[0]
            scriptversion = scriptversion.split('_')[-1]
            if int(assetversion[1:]) + 1 != int(scriptversion[1:]):
                nuke.message(
                    'Script version "{}" needs to be exactly '.format(scriptversion)
                    + 'one over Ftrack asset version "{}"'.format(assetversion)
                )
                session.close()
                return
            for a in assets:
                if assetname == a['name']:
                    asset = a
                    break

        location = session.query('Location where name is "ftrack.server"').one()
        session_upload_media(session, asset, tasknode, location, movpath)
        session_attach_script(session, tasknode, location, scriptname)
        nuke.message('Succesfully uploaded script to Ftrack!')
    
    session.close()

