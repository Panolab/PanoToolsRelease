#!/bin/bash

nukepath=~/.nuke
nukeinit=$nukepath/init.py
panotools=$nukepath/PanoTools
addline="nuke.pluginAddPath('PanoTools')"

mkdir -p $panotools
cp menu.py $panotools/menu.py

for d in *; do
    [ -d $d ] && cp -r $d $panotools || continue
    [ -f $panotools/$d/menu.py ] && rm $panotools/$d/menu.py
done

if grep -Fxq $addline $nukeinit
then
   echo "Updated PanoTools"
else
    lines=$(wc -l $nukeinit | awk '{print $1}')
    lines+=i
    sed -i '' "$lines\\
$addline\\
" $nukeinit 
    echo "Installed PanoTools"   
fi

