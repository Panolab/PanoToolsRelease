# LutDownload

Con un solo click descarga el archivo de LUT correspondiente al plano que se está
trabajando, dejándolo en la carpeta ASSETS, y lo linkea a todos los nodos 
'OCIOFileTransform' del proyecto. Útil para trabajar con LUTS.
 
Para usarlo, presionar el comando 'Download Lut' en la  pestaña 'PanoTools' en la barra de
herramientas superior de Nuke. Al hacerlo se descargará automáticamente el Lut
correspondiente al plano que se está trabajando en el proyecto. El archivo se
guardará en la carpeta ASSETS/LUTS/ correspondiente al proyecto. Si esas carpetas no
existen, serán creadas con el fin de alojar el arhivo descargado. Al mismo tiempo,
todos los nodos 'OCIOFileTransform' del proyecto, incluídos los que estén presentes
dentro del 'Input Process' serán linkeados a este archivo automáticamente.

Es necesario recalcar que la descarga del archivo Lut se hace a partir del nombre
del proyecto de Nuke, por lo que es necesario haber guardado el proyecto como script
de nuke, y debe tener el nombre exacto del plano según la nomesclatura estándar. Si
el proyecto varía en tan solo una letra o dígito a la nomesclatura estándar,
aparecerá un error.

Ejemplo incorrecto bb_101_0290_....nk
Ejemplo incorrecto BB_101_290_....nk
Ejemplo incorrecto BB_0101_0290_....nk

Ejemplo correcto: BB_101_0290_....nk

Vale la pena destacar que para que funcione correctamente, se debe trabajar con
configuraciones de OCIO específicas. La librería OCIO debe estar en su versión 2.0
y ACES en su versión 1.3. Estás opcionesa existen nativamente desde Nuke 14.0
en adelante, o bien se puede configurar en la opción 'custom OCIO config' desde
'Project Settings' en la pestaña 'Color', donde se debe proveer el archivo
'[studio-config-v1.0.0_aces-v1.3_ocio-v2.0.ocio](https://github.com/AcademySoftwareFoundation/OpenColorIO-Config-ACES/releases/download/v1.0.0/studio-config-v1.0.0_aces-v1.3_ocio-v2.1.ocio)'.

Nota: Esta herramienta fue diseñada específicamente para el flujo de trabajo del
proyecto Baby Bandito, para facilitar los cambios de espacios de color que requiere
ese proyecto en específico, por lo que probablemente no es universalmente útil para
otros fines.

## Instalación

A diferencia del resto de las herramientas de las PanoTools, este plugin requiere un
paso adicional para su correcta instalación, ya que requiere el uso de modulos de
Python que no vienen por defecto en Nuke para conectar con internet al realizar la
descarga. Para funcionar correctamente, se deben copiar los modulos de Python
necesarios dentro de una carpeta que debe ser llamada 'PanoModules', que debe estar
dentro de otra llamada 'PanoTools, que a su vez debe estar directamente dentro del 
directorio .nuke. La ruta completa debe ser: .nuke/PanoTools/PanoModules/

Dentro de este directorio deben estar los siguientes modulos completos:

* requests
* certifi
* charset-normalizer
* idna
* urllib3

Copiar la carpeta 'LutDownload' dentro del directorio .nuke sin realizar ningún
cambio. Además, copiar la siguiente línea de código Python al final del archivo
.nuke/init.py

```python
nuke.pluginAddPath('./LutDownload')
```

Para que la instalación surta efecto es necesario cerrar todas las instancias de
Nuke y volver a abrir.

