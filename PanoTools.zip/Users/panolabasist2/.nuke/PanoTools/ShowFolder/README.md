# ShowFolder

Configura que la combinación de teclas 'Alt + O' abra la carpeta en el explorador
que contiene el archivo indicado en 'file' del nodo seleccionado. Útil para
fácilmente ir a los archivos señalados por los nodos 'Read' o 'Write' sin salir
de Nuke y buscarlos manualmente. Funciona para todos los nodos que contengan
un campo llamado 'file'. Requiere exactamente un nodo seleccionado para correr
apropiadamente.

Para usarlo se puede presionar la combinación de teclas 'Alt + O' mientras se está
trabajando en el Node Graph, o bien hacer click derecho en el Node Graph y hacer
click en la opción 'Show Folder'.

Si no hay ningún nodo seleccionado, este comando abrirá la carpeta contenedora
del proyecto. Si hay más de un nodo seleccionado o el nodo seleccionado no tiene
un campo 'file', se mostrará un mensaje indicando la razón del error. De la misma
forma, si la ruta indicada por el nodo seleccionado está vacía, no es válida o no
existe, aparecerá un mensaje indicando la razón del error.

## Instalación

Copiar la carpeta 'ShowFolder' dentro del directorio .nuke sin realizar ningún
cambio. Además, copiar la siguiente línea de código Python al final del archivo
.nuke/init.py

```python
nuke.pluginAddPath('./ShowFolder')
```

Para que la instalación surta efecto es necesario cerrar todas las instancias de
Nuke y volver a abrir.

