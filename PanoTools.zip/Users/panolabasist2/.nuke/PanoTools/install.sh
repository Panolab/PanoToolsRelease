#!/bin/bash

nukepath=~/.nuke
nukeinit=$nukepath/init.py

install() {
    plugin=$1
    plugin_name=$(basename $plugin)
    addline="nuke.pluginAddPath('$nukepath/$plugin_name')"
    addline2="nuke.pluginAddPath(\"$nukepath/$plugin_name\")"

    cp -r $plugin $nukepath
    lines=$(wc -l $nukeinit | awk '{print $1}')
    (($lines > 13)) && lines=13
    lines+=i

    if grep -Fxq "$addline" $nukeinit || grep -Fxq "$addline2" $nukeinit
    then
        echo "Updated $plugin"
    else
        sed -i '' "$lines\\
$addline\\
" $nukeinit 
        echo "Installed $plugin"
    fi

    if [[ $plugin_name == LutDownload ]]
    then
        lutpath=$(echo $nukepath/$plugin_name/LutDownloadModules | sed 's/\//\\\//g')
        sed -i '' "s/REPLACE_ME_PLEASE/$lutpath/g" $nukepath/$plugin_name/$plugin_name.py
    fi
}

(($# < 1)) && echo "Missing plugin directory to install" && exit
[ ! -d $nukepath ] && mkdir -p $nukepath/
[ ! -f $nukeinit ] && cp init.py $nukepath/

case "$1" in
    "all")
        for f in *; do [ -d $f ] && install $f; done;;
    *)
        for arg in "$@"
        do
            [ ! -d $arg ] && echo "Argument is not a directoy or does not exist" && exit
            install $arg
        done;;
esac

