import StartAt
nuke.menu('Nuke').addCommand('PanoTools/Start At', 'StartAt.StartAt()')
