# Written by Eugenio Arteaga A. at Panolab spa.

import nuke
import nukescripts

class StartAtPanel(nukescripts.PythonPanel):
    def __init__(self):
        nukescripts.PythonPanel.__init__(self, 'Start At')
        self.intKnob = nuke.Int_Knob('startAt', 'Start At')
        self.intKnob.setValue(1001)
        self.addKnob(self.intKnob)

def start_at(expr):
    nodes = nuke.selectedNodes('Read')
    if not nodes or len(nodes) == 0:
        nodes += nuke.allNodes('Read')
    
    for n in nodes:
        if int(n['first'].getValue()) != expr:
            n['frame_mode'].setValue('start at')
            n['frame'].setValue(str(expr))

def StartAt():
    panel = StartAtPanel()
    if panel.showModalDialog():
        expr = panel.intKnob.value()
        start_at(expr)

