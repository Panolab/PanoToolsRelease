# StartAt

Cambia la expresión 'start at' de todos los 'Read' nodes seleccionados con un solo
comando. Útil para cambiar frames de inicio, por ejemplo al 1001, a una serie de
'Read' nodes simultáneamente.

Para usarlo, presionar el comando 'Start At' en la  pestaña 'PanoTools' en la barra de
herramientas superior de Nuke. Al hacerlo se presentará una ventana con un campo
para ingresar el número de frame de inicio que se desea configurar para todos los
'Read' nodes seleccionados, y luego presionar 'Ok'. Por defecto vendrá ingresado
el valor '1001', pero se puede cambiar a cualquier expresión válida en Nuke.

Si no hay ningún 'Read' node seleccionado, el comando correrá para todos los 'Read'
nodes del proyecto. Si alguno de los 'Read' nodes ya comienza en el frame indicado,
ya sea por numeración propia o porque ya se configuró en 'start at', este comando 
no hará ningún cambio en esos nodos.

## Instalación

Copiar la carpeta 'StartAt' dentro del directorio .nuke sin realizar ningún
cambio. Además, copiar la siguiente línea de código Python al final del archivo
.nuke/init.py

```python
nuke.pluginAddPath('./StartAt')
```

Para que la instalación surta efecto es necesario cerrar todas las instancias de
Nuke y volver a abrir.

