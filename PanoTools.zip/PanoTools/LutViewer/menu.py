import LutViewer
nuke.menu('Viewer').addCommand('Change Lut', 'LutViewer.LutViewer()', 'alt+p')
