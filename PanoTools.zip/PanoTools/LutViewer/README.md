# LutViewer

Configura que la combinación de teclas 'Alt + P' en el viewer cambien el espacio de
color del output al mismo tiempo que cambia si se usa el input process o no. Útil
para monitorear LUTs que requieren de input process y cambio de espacio de color al
mismo tiempo.

Para usarlo se puede presionar la combinación de teclas 'Alt + P' mientras se está
trabajando en el Viewer, o bien hacer click derecho en el Viewer y hacer
click en la opción 'Change Lut'.

Si no se está trabajando en el Viewer, este comando no hará nada. De la misma forma,
si no hay ningún 'Input Process' en el proyecto, este comando no tiene ningún
efecto.

Vale la pena destacar que para que funcione correctamente, se debe trabajar con
configuraciones de OCIO específicas. La librería OCIO debe estar en su versión 2.0
y ACES en su versión 1.3. Estás opcionesa existen nativamente desde Nuke 14.0
en adelante, o bien se puede configurar en la opción 'custom OCIO config' desde
'Project Settings' en la pestaña 'Color', donde se debe proveer el archivo
'[studio-config-v1.0.0_aces-v1.3_ocio-v2.0.ocio](https://github.com/AcademySoftwareFoundation/OpenColorIO-Config-ACES/releases/download/v1.0.0/studio-config-v1.0.0_aces-v1.3_ocio-v2.1.ocio)'.

Nota: Esta herramienta fue diseñada específicamente para el flujo de trabajo del
proyecto Baby Bandito, para facilitar los cambios de espacios de color que requiere
ese proyecto en específico, por lo que probablemente no es universalmente útil para
otros fines.

## Instalación

Copiar la carpeta 'LutViewer' dentro del directorio .nuke sin realizar ningún
cambio. Además, copiar la siguiente línea de código Python al final del archivo
.nuke/init.py

```python
nuke.pluginAddPath('./LutViewer')
```

Para que la instalación surta efecto es necesario cerrar todas las instancias de
Nuke y volver a abrir.

