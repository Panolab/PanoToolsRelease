# Written by Eugenio Arteaga at Panolab spa

import nuke

def LutViewer():
    colorspaces = ['ACES 1.0 - SDR Video (sRGB - Display)', 'Raw (sRGB - Display)'] 
    viewer = None
    nodes = nuke.allNodes('Viewer')
    for n in nodes:
        viewer = n
        vp = viewer['viewerProcess']
        ip = viewer['input_process']
        ipval = ip.getValue()
        ip.setValue(not ipval)
        vp.setValue(colorspaces[int(not ipval)])
 
