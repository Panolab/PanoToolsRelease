# :coding: utf-8
# :copyright: Copyright (c) 2013 Martin Pengelly-Phillips
# :license: See LICENSE.txt.

'''Custom error classes.'''


class CollectionError(Exception):
    '''Raise when a collection error occurs.'''

