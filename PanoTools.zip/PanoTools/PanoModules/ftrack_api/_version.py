
# :coding: utf-8
# :copyright: Copyright (c) 2014 ftrack

__version__ = '2.5.0'
