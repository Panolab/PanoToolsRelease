# Written by Eugenio Arteaga A. at Panolab spa.

import nuke
import nukescripts

class ChangeColorSpacePanel(nukescripts.PythonPanel):
    def __init__(self):
        nukescripts.PythonPanel.__init__(self, 'Change Color Space')
        colorspaces = nuke.getOcioColorSpaces()
        self.colorKnob = nuke.Enumeration_Knob('colorspace', 'Colorspace:', colorspaces)
        self.colorKnob.setValue('Output - Rec.709')
        self.addKnob(self.colorKnob)

def ChangeColorSpace():
    nodes = nuke.selectedNodes('Read')
    if not nodes or len(nodes) == 0:
        nuke.message('ChangeColorSpace needs at least one Read node selected!')
        return

    panel = ChangeColorSpacePanel()
    if panel.showModalDialog():
        colorspace = panel.colorKnob.value()
        for n in nodes:
            n['colorspace'].setValue(colorspace)

