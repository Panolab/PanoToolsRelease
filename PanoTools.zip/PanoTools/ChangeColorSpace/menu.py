import ChangeColorSpace
nuke.menu('Nuke').addCommand('PanoTools/Change Color Space', 'ChangeColorSpace.ChangeColorSpace()')
