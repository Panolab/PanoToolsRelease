# ChangeColorSpace

Cambia el especio de color de todos los 'Read' nodes seleccionados con un solo
comando. Útil pare cambiar espacios de color en varios 'Read' nodes simultáneamente.
Para usarlo, presionar el comando 'Change Color Space' en la pestaña 'PanoTools' en la
barra de herramientas superior de Nuke.

Al hacerlo se presentará una ventana con una lista de espacios de color
disponibles. Se debe seleccionar el espacio de color que se desea configurar para
todos los 'Read' nodes seleccionados, y luego presionar 'Ok'.

Si no hay ningún 'Read' node seleccionado, un mensaje de error aparecerá indicando
que se requiere al menos un 'Read' node seleccionado para correr apropiadamente.

Vale la pena mencionar que los espacios de color disponibles dependerán de la
configuración actual del proyecto de Nuke, y según las configuraciones de OCIO
seleccionadas.

## Instalación

Copiar la carpeta 'ChangeColorSpace' dentro del directorio .nuke sin realizar ningún
cambio. Además, copiar la siguiente línea de código Python al final del archivo
.nuke/init.py

```python
nuke.pluginAddPath('./ChangeColorSpace')
```

Para que la instalación surta efecto es necesario cerrar todas las instancias de
Nuke y volver a abrir.

