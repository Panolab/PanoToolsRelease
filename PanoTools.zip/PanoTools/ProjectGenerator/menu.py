import ProjectGenerator
nuke.menu('Nuke').addCommand('PanoTools/Project Generator', 'ProjectGenerator.ProjectGenerator()')
