# Written by Eugenio Arteaga A. at Panolab spa.

import nuke
import nukescripts
import os

class ProjectGeneratorPanel(nukescripts.PythonPanel):
    def __init__(self):
        nukescripts.PythonPanel.__init__(self, 'Project Generator')
        self.dnameKnob = nuke.String_Knob('directory', 'Folder name:')
        self.snameKnob = nuke.String_Knob('script', 'Script name:')
        self.pathKnob = nuke.File_Knob('path', 'Path:')
        self.createKnob = nuke.Boolean_Knob('root', 'create directories:')
        self.createKnob.setFlag(nuke.STARTLINE)
        self.addKnob(self.pathKnob)
        self.addKnob(self.dnameKnob)
        self.addKnob(self.snameKnob)
        self.addKnob(self.createKnob)

def projgen(path, dname, sname, create):
    if not path or len(path) == 0:
        nuke.message('Project path cannot be empty!')
        return
    if not dname or len(dname) == 0:
        nuke.message('Folder name cannot be empty!')
        return
    if not sname or len(sname) == 0:
        nuke.message('Script name cannot be empty!')
        return
    
    dirpath = os.path.join(path, dname).replace('\\', '/')
    if create == False:
        if not os.path.exists(path):
            nuke.message('Directory does not exist: ' + path)
            return
        if not os.path.isdir(path):
            nuke.message('Path is not a directory: ' + path)
            return
    elif not os.path.exists(path):
        os.makedirs(path)
    
    if not os.path.exists(dirpath):
        os.mkdir(dirpath)

    dirs = ['ASSETS', 'COMPO', 'MEDIA', 'RENDERS', 'RENDERS/EXR', 'RENDERS/MOV']
    for d in dirs:
        dpath = os.path.join(dirpath, d).replace('\\', '/')
        if not os.path.exists(dpath):
            os.mkdir(dpath)
   
    root = nuke.root()
    root['format'].setValue('UHD_4K')
    root['first_frame'].setValue(1001)
    root['last_frame'].setValue(1100)

    foundver = False
    sbase = os.path.splitext(sname)[0]
    sparts = sbase.split('_')
    for part in sparts:
        if (part[0] == 'v' or part[0] == 'V') and part[1:].isdigit():
            foundver = True
            break

    if foundver == False:
        sname = sbase + '_v001'
    sname += '.nk'

    script_name = os.path.join(dirpath, dirs[1], sname).replace('\\', '/')
    if not os.path.exists(script_name):
        nuke.scriptSave(script_name)
    nuke.scriptOpen(script_name)

def ProjectGenerator():
    panel = ProjectGeneratorPanel()
    if panel.showModalDialog():
        path = panel.pathKnob.getValue()
        dname = panel.dnameKnob.getValue()
        sname = panel.snameKnob.getValue()
        create = panel.createKnob.getValue()
        projgen(path, dname, sname, create)

