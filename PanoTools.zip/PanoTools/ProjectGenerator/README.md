# ProjectGenerator

Genera estructuras de proyectos y directorios automáticamente, creando las carpetas
ASSETS, COMPO, MEDIA y RENDERS. Útil para comenzar nuevos proyectos de Nuke fácil 
y rápidamente. Al mismo tiempo, se guardará el script con el nombre del proyecto en
su versión 001, y se configurará el formato a UHD_4K, además de comenzar en el proyecto
en el frame 1001.

Esta herramienta no solo genera las estructuras de carpetas de un proyecto estándar,
sino que también guarda el proyecto actual como un nuevo script, por lo que se
recomienda usarlo desde un proyecto de Nuke que no haya sido guardado, o cuando
recién se abrió Nuke.

Para usarlo, presionar el comando 'Project Generator' en la  pestaña 'PanoTools' en la barra
de herramientas superior de Nuke. Al hacerlo se presentará una ventana con campos
para directorio, nombre de carpeta y nombre de script. Todos los campos son
obligatorios y aparecerá un mensaje de error si alguno de ellos está vacío. Al final
aparece una opción para indicar si se quiere crear directorios o no.

El campo de directorio corresponde a la ruta donde se desea crear el proyecto con su
estructura de carpetas. Si la opción de crear directorios está deshabilitada y la
ruta no existe, se generará un error. Vale la pena mencionar que esta ruta
corresponde al lugar en el sistema donde se quiere establecer la nueva raíz para el
proyecto generado. Aquí es donde se creará una carpeta con el nombre indicado por el
segundo campo de nombre de carpeta. No hay problema si esta carpeta ya existe. De la
misma forma, si esta carpeta ya existe, y por ejemplo, ya existe una carpeta llamada
MEDIA dentro de ella, esta herramienta no sobreescribirá las carpetas ya existentes.
El último campo corresponde al nombre que se quiere poner al proyecto de nuke. Si no
se pone la extensión de archivo .nk, esta será dada automáticamente.

## Instalación

Copiar la carpeta 'PathGenerator' dentro del directorio .nuke sin realizar ningún
cambio. Además, copiar la siguiente línea de código Python al final del archivo
.nuke/init.py

```python
nuke.pluginAddPath('./PathGenerator')
```

Para que la instalación surta efecto es necesario cerrar todas las instancias de
Nuke y volver a abrir.

