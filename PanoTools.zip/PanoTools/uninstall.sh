#!/bin/bash

nukepath=~/.nuke
nukeinit=$nukepath/init.py
panotools=$nukepath/PanoTools

uninstall() {
    [ -d $panotools ] && rm -r $panotools || echo "Could not find '$panotools'"
    [ ! -f $nukeinit ] && echo "Missing $nukeinit file" && return
    sed -i '' -e '/nuke.pluginAddPath(/!b' -e "/PanoTools/d" $nukeinit
    echo "Uninstalled PanoTools"
}

[ ! -d $nukepath ] && echo "$0: could not find .nuke folder" && exit
uninstall

