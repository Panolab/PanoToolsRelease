#!/bin/bash

nukepath=~/.nuke
nukeinit=$nukepath/init.py

uninstall() {
    plugin=$1
    pluginpath=$nukepath/$plugin
    [ -d $pluginpath ] && rm -r $pluginpath || echo "Could not find '$pluginpath'"
    [ ! -f $nukeinit ] && echo "Missing $nukeinit file" && return
    sed -i '' -e '/nuke.pluginAddPath(/!b' -e "/$plugin/d" $nukeinit
    echo "Uninstalled $plugin"
}

(($# < 1)) && echo "Missing plugin to uninstall" && exit
[ ! -d $nukepath ] && echo "Could not find .nuke folder" && exit

case "$1" in
    "all")
        for f in *; do [ -d $f ] && uninstall $f; done;;
    *)
        for arg in "$@"; do uninstall $arg; done;;
esac
 
