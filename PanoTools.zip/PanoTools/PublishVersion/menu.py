import PublishVersion
nuke.menu('Nuke').addCommand('PanoTools/Publish Version', 'PublishVersion.PublishVersion()')
