# Written by Eugenio Arteaga at Panolab spa

import nuke
import nukescripts
import os
import sys

FKEY = '.ftrack_key'
FSERVER = 'https://panolab.ftrackapp.com'
HOMEPATH = os.path.expanduser('~')
NUKEPATH = os.path.join(HOMEPATH, '.nuke')

sys.path.append(os.path.join(NUKEPATH, 'PanoTools', 'PanoModules'))
import ftrack_api

class FkeyPanel(nukescripts.PythonPanel):
    def __init__(self):
        nukescripts.PythonPanel.__init__(self, 'Ftrack Key')
        self.mailKnob = nuke.String_Knob('mail', 'Mail:')
        self.keyKnob = nuke.String_Knob('key', 'Ftrack Key:')
        self.addKnob(self.mailKnob)
        self.addKnob(self.keyKnob)

def write_fkey_file(path, mail, fkey):
    file = open(path, 'w')
    file.writelines([mail + '\n', fkey])
    file.close()

def read_fkey_file(path):
    with open(path) as file:
        lines = [line.rstrip() for line in file]
    return lines

def find_mov_recursive(pdir, name):
    dirs = os.listdir(pdir)
    for d in dirs:
        dpath = os.path.join(pdir, d)
        if not os.path.isdir(dpath):
            if d == name + '.mov' or d == name + '.MOV':
                return dpath
        else:
            ret = find_mov_recursive(dpath, name)
            if ret and len(ret) != 0:
                return ret
    return ''

def find_mov(scriptname):
    fdir, fname = os.path.split(scriptname)
    return find_mov_recursive(os.path.dirname(fdir), os.path.splitext(fname)[0])

def session_attach_script(session, fshot, user, scriptname):
    note = fshot.create_note('Adjunto script', author=user)
    name = os.path.splitext(os.path.basename(scriptname))[0]
    server_location = session.query('Location where name is "ftrack.server"').one()
    component = session.create_component(
        scriptname, data={'name': name}, location=server_location
    )

    session.create('NoteComponent', {'component_id': component['id'], 'note_id': note['id']})
    session.commit()

def ftrack_connect():
    fkey_path = os.path.join(NUKEPATH, FKEY)
    while not os.path.exists(fkey_path):
        panel = FkeyPanel()
        if panel.showModalDialog():
            mail = panel.mailKnob.value().strip()
            fkey = panel.keyKnob.value().strip()
            write_fkey_file(fkey_path, mail, fkey)
        else: return None
    fkey_lines = read_fkey_file(fkey_path)
    mail = fkey_lines[0]
    fkey = fkey_lines[1]
    try: session = ftrack_api.Session(server_url=FSERVER, api_key=fkey, api_user=mail)
    except: session = None
    return session

def PublishVersion():
    try:
        scriptname = nuke.scriptName()
    except:
        nuke.message('It seems you have not saved your script yet')
        return

    movpath = find_mov(scriptname)
    if not movpath or len(movpath) == 0:
        nuke.message('Could not find a .mov file with the name and version of the project')
        return

    session = ftrack_connect()
    if session == None:
        nuke.message('Could not connect to Ftrack')
        return

    shotname = '_'.join(os.path.basename(scriptname).split('_')[:3])
    shots = session.query('Shot where name like "{}%"'.format(shotname))
    if not shots or len(shots) == 0:
        nuke.message('Could not find shot in Ftrack with name similar to: ' + shotname)
        session.close()
        return 

    """
    assets = session.query('Asset where name like "{}%"'.format(shotname))
    if not assets or len(assets) == 0:


    job = session.encoding_media(movpath)
    
    user = session.query('User where email is "{}"'.format(mail)).one()
    shots = session.query('Shot where name is "{}"'.format(shotname))
    if not shots or len(shots) == 0:
        nuke.message('Could not find shot on Ftrack called: ' + shotname)
        session.close()
        return
    """

    session_attach_script(session, shots[0], user, scriptname)
    session.close()
    nuke.message('Succesfully uploaded script to Ftrack!')

