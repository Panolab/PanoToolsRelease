# PublishVersion

Integración de Nuke y Ftrack con la finalidad de facilitar la publicación de
versiones a la plataforma de Ftrack, subiendo el render en .mov y el script
correspondiente.

# Ftrack

Solo si es la primera vez que usas esta herramienta, aparecerá una ventana especial
titulada 'Ftrack Key'. Esta ventana presenta dos campos a llenar, uno para el mail
y el otro para la Ftrack API Key. En el primer campo debes escribir el mail bajo el
cual tengas tu cuenta de Ftrack.

La llave de Ftrack a poner en el segundo campo debes buscarla directamente en un navegador,
dentro de la plataforma de Ftrack. Una vez en la plataforma, presionar en el ícono
de tu cuenta en la esquina superior derecha. Luego, en el menú desplegable ir a 'My
Account'. Una vez en las configuraciones de tu cuenta, presionar 'Security settings'
en el menu lateral izquierdo. Por último, ir al cuadro 'Personal API key' y generar
tu llave personal de Ftrack.

Una vez generada la llave, copiarla y pegarla en el campo 'Ftrack Key' y apretar Ok.
Esto generará un archivo escondido dentro de tu carpeta .nuke llamado .ftrack_key
donde se guardará esta información para no tener que preguntar estos datos cada vez
que se usa la herramienta.

Nota: En Ftrack puedes generar tu llave tantas veces como quieras, pero solo puedes 
verla en una ocasión, por lo que se recomienda guardar la llave en un lugar seguro.

# Uso

Para usar la herramienta solo basta ir a 'PanoTools' en la barra superior de Nuke,
y presionar la opción 'Publish Version'. Para ello, tu proyecto de Nuke debe estar
títulado según la nomesclatura estándar y el principio del nombre debe corresponder
exactamente con el nombre del plano en Ftrack (considerar mayúsculas y cantidad de
digitos en la numeración). Aparecerá un error si no existe un plano en Ftrack con
el mismo nombre que tu proyecto de Nuke. De la misma forma, la herramienta buscará
recursivamente en todo el directorio de tu proyecto si existe un archivo .mov con
el mismo nombre y versión que tu proyecto de Nuke. Si no lo encuentra, aparecerá
un error indicando la razón. 

Si todo va bien, aparecerá una primera ventana con una lista de tareas disponibles
en Ftrack para el plano que se quiere publicar. Por defecto vendrá seleccionada la
tarea 'Compositing', si esta existe. Si se desea publicar en otra tarea, solo basta
seleccionarla desde la lista.

Al presionar Ok en esta primera ventana, aparecerá una segunda ventana. Esta segunda
ventana puede tener uno o dos campos; si no se encuentra ningún asset publicado en
la plataforma de Ftrack para el plano indicado, solo aparecerá un campo para
ingresar un nuevo nombre para el asset a crear. En el caso de que se encuentren
assets ya subidos a la plataforma para el plano trabajado, también aparecerá una
lista de assets disponibles. En este caso, tienes dos opciones; si escribes en el
primer campo se va a crear un nuevo asset con el nombre que indicaste, pero si dejas
este primer campo vacío, la media se subirá como una nueva versión del asset
señalado en la lista de assets. Se recomienda siempre elegir un asset de la lista
para ir generando nuevas versiones en vez de crear nuevos assets en su primera
versión, a menos que se esté subiendo media para una tarea por primera vez o se
tenga algún motivo específico para no usar los assets presentados en la lista.

Al presionar Ok, se comenzará a subir la media y se adjuntará el script del proyecto
de Nuke en la plataforma de Ftrack. Esto puede tardar aproximadamente 30 segundos
dependiendo de la velocidad de internet. Al terminar la carga aparecerá un mensaje
indicando que los archivos fueron stisfactoriamente subidos a Ftrack.

## Instalación

Copiar la carpeta 'PublishVersion' dentro del directorio .nuke sin realizar ningún
cambio. Además, copiar la siguiente línea de código Python al final del archivo
.nuke/init.py

```python
nuke.pluginAddPath('PublishVersion')
```

Para que la instalación surta efecto es necesario cerrar todas las instancias de
Nuke y volver a abrir.

