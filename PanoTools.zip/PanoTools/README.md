# PanoTools

PanoTools-2.0.0

Colección de scripts de Python, plug-ins y otras herramientas para trabajar en Nuke. 
Desde utilidades básicas y ayudas simples para el uso diario de Nuke, hasta herramientas
específicamente diseñadas para el Pipeline de Panolab, haciendo integraciones
con plataformas de trabajo como frame.io y ftrack.

* ChangeColorSpace: cambia el espacio de color en varios nodos 'Read' a la vez.
* ImportRender: importa un render hecho por un nodo 'Write' con 'Alt + R'.
* LutDownload: descarga LUT correspondiente al plano y lo linkea al proyecto.
* LutViewer: cambia el espacio de color para monitorear LUTs con 'Alt + P'.
* PublishVersion: publica versiones y proyectos de Nuke a ftrack con un solo click.
* PathGenerator: genera expresiones con rutas relativas para tus nodos 'Write'.
* ProjectGenerator: genera estructuras de directorios estándar de proyecto de Nuke.
* ShowFolder: abre la carpeta donde está el archivo del nodo seleccionado con 'Alt + O'.
* StartAt: cambia el frame de inicio de varios nodos 'Read' a la vez.
* UpdateTools: actualiza tus PanoTools automáticamente sin salir de Nuke.
* VersionDownload: descarga versiones de tus planos de Ftrack a Nuke en un solo click.

## Shortcuts

* 'Alt + O': abrir archivo indicado por el nodo seleccionado en el explorador.
* 'Alt + R': importar automáticamente render hecho por 'Write' node seleccionado.
* 'Alt + P': cambiar input process y espacio de color en el viewer para monitoreo.

## Instalación

Se puede instalar automáticamente a través de un script de instalación, o manualmente.
Ambas instalaciones hacen exactamente las mismas operaciones en el sistema. Para que
la instalación surta efecto es necesario cerrar todas las instancias de Nuke y volver 
a abrirlo.

### Instalación Automática

Existen dos scripts de instalación y dos scripts de desinstalación.
Los scripts llamados 'install.bat' y 'uninstall.bat' son exclusivos para Windows, 
mientras que los scripts 'install.sh' y 'uninstall.sh' sirven tanto para MacOS 
como para Linux.

### Instalación Automática en Windows

Para instalar las PanoTools en Windows se puede simplemente hacer doble click en 
el archivo 'install.bat', o bien se puede ejecutar en una consola de comandos desde
la carpeta donde recide este archivo, escribiendo 'install.bat' y presionando
'Enter'. Si se ejecutó haciendo doble click, esto abrirá una terminal donde se
correrán una serie de comandos y luego se cerrará rápidamente. Una vez hecho esto
los archivos y directorios correspondientes quedarán dentro de la carpeta .nuke,
y ya se puede eliminar o hacer lo que se desee con la carpeta de instalación.

Nota: NUNCA CORRER EL INSTALADOR DE WINDOWS COMO ADMINISTRADOR!!

### Instalación Automática en MacOS y Linux

Para instalar las PanoTools en MacOS y Linux se debe abrir una terminal en la
carpeta de instalación, donde reside el archivo 'install.sh'. A diferencia de la
instalación en Windows, el script de instalación de MacOS y Linux se debe correr
desde una terminal. Para ello, se debe abrir una terminal en la ruta donde existe el
script de instalación, y luego correr el siguiente comando..

```shell
./install.sh
```

### Instalación Manual

La instalación manual de las PanoTools es igual para Windows, MacOS y Linux.
Para instalar manualmente las PanoTools hay dos pasos a seguir.

* 1)

Copiar o mover la carpeta correspondiente a las PanoTools dentro de la carpeta 
.nuke en tu sistema. Es muy importante no realizar ningún otro cambio en la 
carpeta y archivos que se están moviendo o copiando.

* 2)

Agregar una línea de código Python en el archivo init.py que existe dentro
de la carpeta .nuke. Si no existe este archivo, puedes copiar el archivo init.py
de este repositorio dentro de la carpeta .nuke y luego editarlo.

Línea a agregar al final de tu archivo init.py:

```Python
nuke.pluginAddPath('PanoTools')
```

Tener en cuenta mayúsculas. Consideración por los símbolos <'> que rodean la ruta,
ya que algunos sistemas pueden cambiarlos automáticamente al copiar y pegar, y
pueden no ser compatibles con la sintaxis de Python.

## Actualizar

Para actualizar tus PanoTools a una nueva versión puedes simplemente correr los
scripts de instalación nuevamente, ellos están pensados para ser usados múltiples
veces sin generar problemas, facilitando la fácil actualización de las herramientas.
Para actualizar manualmente solo se deben copiar las carpetas correspondientes a las
tools en la raíz de la carpeta .nuke sobreescribiéndo las carpetas con los mismos
nombres. Por último, existe la herramiento UpdateTools dentro de las PanoTools, que
te permite actualizar las PanoTools automáticamente desde Nuke, yendo a la barra de
herramientas superior, haciendo click en 'PanoTools' y luego 'Update Tools' en la
lista desplegable.

Para que la actualización surta efecto es necesario cerrar todas las instancias de
Nuke y volver a abrirlo.

## Desinstalación

Los scripts de desinstalación funcionan exactamente igual que los de instalación. En
Windows se puede simplemente hacer doble click en 'uninstall.bat', mientras que en
MacOS y Linux se debe correr el script 'uninstall.sh' desde una terminal, 
específicando si se desean desinstalar todos los plugins, o cuales particularmente,
de la misma forma que se debe hacer con el archivo 'install.sh' para la instalación.

Para desinstalar manualmente, se deben borrar las carpetas correspondientes a las
tools del interior del directorio .nuke. Luego se deben borrar las líneas que hacen
alusión a la herramienta del archivo .nuke/init.py.

Para que la desinstalación surta efecto es necesario cerrar todas las instancias de
Nuke y volver a abrirlo.

## Tools

A continuación hay un listado de las herramientas que incluye este repositorio y lo
que cada una hace. Para acceder a estos plugins puedes presionar el menú 'PanoTools'
presente en la barra de herramientas superior en Nuke.

### ChangeColorSpace

Cambia el especio de color de todos los 'Read' nodes seleccionados con un solo
comando. Útil pare cambiar espacios de color en varios 'Read' nodes simultáneamente.

### ImportRender

Configura que la combinación de teclas 'Alt + R' importen el render de un 'Write' node
seleccionado como un nuevo 'Read' node. Útil para fácil y rápidamente traer a Nuke
renders para revisión u otros fines.

### LutDownload

Con un solo click descarga el archivo de LUT correspondiente al plano que se está
trabajando, dejándolo en la carpeta ASSETS, y lo linkea a todos los nodos 
'OCIOFileTransform' del proyecto. Útil para trabajar con LUTS.

### LutViewer

Configura que la combinación de teclas 'Alt + P' en el viewer cambien el espacio de
color del output al mismo tiempo que cambia si se usa el input process o no. Útil
para monitorear LUTs que requieren de input process y cambio de espacio de color al
mismo tiempo.

### PathGenerator

Genera expresiones de rutas relativas para 'Write' nodes automáticamente según el
nombre del proyecto, extensión de archivo, versión y tipo de render. Útil para
generar rutas para generar renders de 'proxy' o 'dns' sin complicarse con escribir
manualmente las rutas en los nodos 'Write'.

### ProjectGenerator

Genera estructuras de proyectos y directorios automáticamente, creando las carpetas
ASSETS, COMPO, MEDIA y RENDERS y guardando el script dentro del directorio COMPO.
Útil para comenzar nuevos proyectos de Nuke fácil y rápidamente.

## PublishVersion

Integración de Nuke con Ftrack con la finalidad de facilitar la publicación de
versiones. Con un solo click te permite subir una nueva versión a Ftrack y respaldar
el proyecto de Nuke en la plataforma.

### ShowFolder

Configura que la combinación de teclas 'Alt + O' abra la carpeta en el explorador
del sistema operativo que contiene el archivo indicado en 'file' del nodo
seleccionado. Útil para fácilmente ir a los archivos señalados por los nodos 'Read'
o 'Write' sin salir de Nuke y buscarlos manualmente. Funciona para todos los nodos
que contengan un knob 'file'.

### StartAt

Cambia la expresión 'start at' de todos los 'Read' nodes seleccionados con un solo
comando. Útil para cambiar frames de inicio, por ejemplo al 1001, a una serie de
'Read' nodes simultáneamente.

### UpdateTools

Herramienta para actualizar todo el conjunto de tools de PanoTools con un solo
click, y sin salir de Nuke.

### VersionDownload

Descarga las últimas versiones de tus planos desde Ftrack a Nuke en un solo click.
Ya sea el plano que estás trabajando, o una secuencia de planos, en su última
version, o en la que tu quieras, facilita la revisión de versiones de Ftrack sin
salir de Nuke.

