import PathGenerator
nuke.menu('Nuke').addCommand('PanoTools/Path Generator', 'PathGenerator.PathGenerator()')
