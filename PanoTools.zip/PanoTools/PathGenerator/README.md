# PathGenerator

Genera expresiones de rutas relativas para 'Write' nodes automáticamente según el
nombre del proyecto, extensión de archivo, versión y tipo de render. Útil para
generar rutas para generar renders de 'proxy' o 'dns' sin complicarse con escribir
manualmente las rutas en los nodos 'Write'. 

Todas las rutas se generan a partir del nombre del proyecto de Nuke, por lo que es
importante haber guardado con una nomesclatura correcta, o las rutas generadas 
tendrán los mismos errores que el nombre de tu proyecto.

Para usarlo, presionar el comando 'Path Generator' en la  pestaña 'PanoTools' en la barra
de herramientas superior de Nuke. Al hacerlo se presentará una ventana con campos
para directorio, extensión de archivo, tipo de render y versión. Los campos de
directorio y extensión de archivo son obligatorios, y no pueden ir vacíos
o aparecerá un error. Los campos de tipo de render y versión son opcionales,
y pueden ir vacíos sin problemas.

El campo de directorio indica donde se desea poner el render. Si la ruta no existe,
será creada. El campo de extensión de archivo indica qué formato se desea para el
render, y debe corresponder a una extensión de archivo válida, reconocida por Nuke,
y con soporte para render. Vale la pena mencionar que si la extensión de archivo
corresponde a secuencia de imágenes, se creará por defecto una carpeta contenedora
con el mismo nombre para el render, mientras que si corresponde a video se pondrá el
render en la ruta exacta indicada por el campo de directorio.

El campo de tipo de render indica el descriptor que se desee poner al render, según
la finalidad del mismo. Por ejemplo, si se desea realizar un Denoise, es común poner
en el nombre del render las siglas DNS, o si se quiere hacer un proxy, es común
agregarlo al nombre del render. Este descriptor reemplazará la parte del nombre 
que dice '_cmp_', '_paint_', '_roto_' o '_track_' en tu proyecto, según sea el caso. 
Si tu proyecto no tiene esta parte en el nombre, simplemente se agregará el descriptor
indicado. Por otro lado, si este campo se deja vacío, la ruta generada será igual al
nombre de tu proyecto, sin descriptor o cambios.

Por último, el campo de versión indica la versión que se le quiere dar al render. Si
se deja vacío, la ruta generada tendrá la misma versión que tu proyecto actual. Por
otro lado, si se especifica, la ruta reemplazará la versión de tu proyecto por la
indicada en este campo.

Algunos otros requerimientos son tener exactamente un nodo 'Write' seleccionado.
La extensión de archivo debe necesariamente comenzar con un
punto. La ruta indicada por el campo de directorio debe apuntar a una carpeta,
exista esta o no, pero nunca a un archivo. El campo de versión debe tener al menos
un dígito. Si no se cumplen estos requerimientos se mostrará un mensaje indicando la
razón del error.

## Instalación

Copiar la carpeta 'PathGenerator' dentro del directorio .nuke sin realizar ningún
cambio. Además, copiar la siguiente línea de código Python al final del archivo
.nuke/init.py

```python
nuke.pluginAddPath('./PathGenerator')
```

Para que la instalación surta efecto es necesario cerrar todas las instancias de
Nuke y volver a abrir.

