# Written by Eugenio Arteaga A. at Panolab spa.

import nuke
import nukescripts
import os

class PathGeneratorPanel(nukescripts.PythonPanel):
    def __init__(self):
        nukescripts.PythonPanel.__init__(self, 'Path Generator')
        self.pathKnob = nuke.File_Knob('path', 'Directory:')
        self.extKnob = nuke.String_Knob('extension', 'File Extension:', '.exr')
        self.textKnob = nuke.String_Knob('type', 'Type:')
        self.pathKnob.setValue('../RENDERS/EXR/')
        self.versionKnob = nuke.String_Knob('version', 'Version:')
        
        self.addKnob(self.pathKnob)
        self.addKnob(self.extKnob)
        self.addKnob(self.textKnob)
        self.addKnob(self.versionKnob)

def strcheck(s, ext):
    return s == ext or s.lower() == ext

def issecuence(ext):
    for e in ['.exr', '.jpeg', '.jpg', '.png', '.tiff', '.tif', '.dpx']:
        if strcheck(ext, e):
            return True
    return False

def getindex(types):
    parts = os.path.splitext(nuke.scriptName())[0].split('_')
    for t in types:
        for i in range(len(parts)):
            if strcheck(t, parts[i]):
                return i
    return -1

def pathgen(node, path, ext, name, version):
    types =  ['CMP', 'COMP', 'COMPO', 'ROTO', 'PAINT', 'DNS', 'TRACK', 'TRACKING']
    customVer = version != None and len(version) != 0

    if not path or len(path) == 0:
        nuke.message('Path cannot be empty!')
        return 
    if not ext or len(ext) == 0:
        nuke.message('File extension cannot be empty!')
        return
    if ext[0] != '.':
        nuke.message('File extension must start with a dot!')
        return
    if customVer == True:
        if not any(i.isdigit() for i in version):
            nuke.message('Version must contain at least one digit!')
            return
        elif version[0].isdigit():
            version = 'v' + version

    path = path.replace('\\', '/')
    abspath = os.path.join(nuke.script_directory(), path).replace('\\', '/')
    exists = os.path.exists(abspath)
    if exists and not os.path.isdir(abspath):
        nuke.message('Path is not a directory: ' + abspath)
        return

    index = getindex(types)
    secuence = issecuence(ext)
    createdirs = secuence == True or exists == False
    noname = not name or len(name) == 0

    if noname == True:
        if customVer == True:
            fullpath = '[file tail [join [lreplace [split [file rootname [value root.name]] _ ] end end ' + version + ' ] _ ]]'
        else:
            fullpath = '[file tail [file rootname [value root.name]]]'
    else:
        fullpath = '[file tail [join '
        if index >= 0:
            fullpath += '[lreplace '
        else:
            fullpath += '[linsert '
        if customVer == True:
            fullpath += '[lreplace '
        fullpath += '[split [file rootname [value root.name]] _ ] '
        if customVer == True:
            fullpath += 'end end ' + version + ' ] '
        if index >= 0:
            fullpath += str(index) + ' ' + str(index) + ' '
        else:
            fullpath += 'end-1 ' if customVer == False else 'end '
        fullpath += name + ' ] _ ]]'

    if secuence == True:
        fullpath += '/' + fullpath
    if path[-1] != '/':
        path += '/'
    fullpath = path + fullpath
    if path[0] == '.':
        fullpath = '[python {nuke.script_directory()}]/' + fullpath
    if secuence == True:
        fullpath += '_%04d'
    fullpath += ext
    fullpath = fullpath.replace('\\', '/')
    fullpath = fullpath.replace('//', '/')

    node['file'].setValue(fullpath)
    if createdirs == True:
        node['create_directories'].setValue(True)
    if strcheck(ext, '.exr'):
        node['channels'].setValue('rgba')
    elif strcheck(ext, '.mov'):
        node['colorspace'].setValue('Output - Rec.709')
    
def PathGenerator():
    nodes = nuke.selectedNodes('Write')
    if len(nodes) != 1:
        nuke.message('There must be exactly one Write node selected!')
        return

    panel = PathGeneratorPanel()
    if panel.showModalDialog():
        path = panel.pathKnob.value()
        ext = panel.extKnob.value()
        name = panel.textKnob.value()
        version = panel.versionKnob.value()
        pathgen(nodes[0], path, ext, name, version)

