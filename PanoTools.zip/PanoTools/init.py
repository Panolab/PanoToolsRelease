import nuke

nuke.pluginAddPath('PanoTools')

