#!/bin/bash

nukepath=~/.nuke
nukeinit=$nukepath/init.py
panotools=$nukepath/PanoTools

unplugins=(
    ChangeColorSpace
    ImportRender
    LutDownload
    LutViewer
    PathGenerator
    ProjectGenerator
    ShowFolder
    StartAt
)

plugins=(
    ${unplugins[*]}
    PanoModules
    PublishVersion
    UpdateTools
    VersionDownload
)

files=(
    menu.py
    README.md
    install.sh
    install.bat
    uninstall.sh
    uninstall.bat
)

uninstall() {
    plugin=$1
    pluginpath=$nukepath/$plugin
    [ -d $pluginpath ] && rm -r $pluginpath || echo "Could not find '$pluginpath'"
    [ ! -f $nukeinit ] && echo "Missing $nukeinit file" && return
    sed -i '' -e '/nuke.pluginAddPath(/!b' -e "/$plugin/d" $nukeinit
    echo "Uninstalled $plugin"
}

install() {
    addline="nuke.pluginAddPath('PanoTools')"
    [ -d $panotools ] || mkdir -p $panotools
    for f in ${files[*]}; do [ -f $f ] && cp $f $panotools || continue; done
    for d in ${plugins[*]}; do [ -d $d ] && cp -r $d $panotools || continue; done
    [ -f $nukeinit ] || cp init.py $nukepath

    if grep -Fxq $addline $nukeinit
    then
       echo "Updated PanoTools"
    else
        lines=$(wc -l $nukeinit | awk '{print $1}')
        lines+=i
        sed -i '' "$lines\\
$addline\\
" $nukeinit 
        echo "Installed PanoTools"  
    fi
}

[ ! -d $nukepath ] && echo "$0: could not find .nuke folder" && exit
for f in ${unplugins[*]}; do [ -d $f ] && uninstall $f; done
install

