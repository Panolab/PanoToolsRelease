import ShowFolder
nuke.menu('Node Graph').addCommand('Show Folder', 'ShowFolder.ShowFolder()', 'alt+o')
