# Written by Eugenio Arteaga at Panolab spa

import nuke
import os
import platform
import subprocess

def open_folder(path):
    if platform.system() == 'Windows':
        os.startfile(path)
    else:
        opener = 'open' if platform.system() == 'Darwin' else 'xdg-open'
        subprocess.Popen([opener, path])

def show_folder(path):
    if not path or len(path) == 0:
        nuke.message('Cannot show encolsing folder because path is empty in this node')
        return
    
    path = os.path.dirname(path.replace('\\', '/'))
    if not os.path.exists(path):
        nuke.message('Cannot show enclosing folder because path does not exist: ' + path)
    else: 
        open_folder(path)

def ShowFolder():
    nodes = nuke.selectedNodes()
    if not nodes or len(nodes) == 0:
        return
    elif len(nodes) != 1:
        nuke.message('ShowFolder needs exactly one node selected')
    elif not nodes[0].knob('file'):
        nuke.message('ShowFolder needs a node with a \'file\' knob selected')
    else:
        show_folder(nuke.filename(nodes[0]))

