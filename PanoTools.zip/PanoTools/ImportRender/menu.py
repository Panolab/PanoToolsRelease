import ImportRender
nuke.menu('Node Graph').addCommand('Import Render', 'ImportRender.ImportRender()', 'alt+r')
