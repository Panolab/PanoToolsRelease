# Written by Eugenio Arteaga A. at Panolab spa

import nuke
import os

def issecuence(ext):
    for e in ['.exr', '.jpeg', '.jpg', '.png', '.tiff', '.tif', '.dpx']:
        if ext == e or ext.lower() == e:
            return True
    return False

def file_exists(path):
    dpath = os.path.dirname(path)
    fname, ext = os.path.splitext(os.path.basename(path))
    fname = fname.replace('####', '')
    files = os.listdir(dpath)
    for f in files:
        if f.endswith(ext) and fname in f:
            return (True, 1, 1)
    return (False, 1, 1)

def file_check(path):
    found = False
    fmin, fmax = 999999999, 1
    dpath = os.path.dirname(path)
    fname, ext = os.path.splitext(os.path.basename(path))
    fname = fname.replace('####', '')
    files = os.listdir(dpath)
    for f in files:
        if f.endswith(ext) and fname in f:
            frame = int(os.path.splitext(f)[0].split('_')[-1])
            if frame < fmin: fmin = frame
            if frame > fmax: fmax = frame
            found = True
    return (found, fmin, fmax)

def ImportRender():
    nodes = nuke.selectedNodes('Write')
    if not nodes or len(nodes) != 1:
        nuke.message('ImportRender needs exactly one Write node selected')
        return

    w = nodes[0]
    path = nuke.filename(w)
    if not path or len(path) == 0:
        nuke.message('Selected Write node has no valid file path')
        return

    path = path.replace('%04d', '####')
    secuence = issecuence(os.path.splitext(path)[1])
    tup = file_check(path) if secuence else file_exists(path)
    if not tup[0]:
        nuke.message('The file of selected Write node does not exist yet: ' + path)
        return
    
    path = path.replace('\\', '/')
    nkfirst = nuke.root().firstFrame()

    r = nuke.createNode('Read')
    r['file'].fromUserText(path)
    r['xpos'].setValue(w['xpos'].getValue() + 40)
    r['ypos'].setValue(w['ypos'].getValue() + 40)
    if secuence:
        r['first'].setValue(tup[1])
        r['last'].setValue(tup[2])
        r['origfirst'].setValue(tup[1])
        r['origlast'].setValue(tup[2])
    if r['first'].getValue() != nkfirst:
        r['frame_mode'].setValue('start at')
        r['frame'].setValue(str(nkfirst))

