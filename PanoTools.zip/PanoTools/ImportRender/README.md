# ImportRender

Configura que la combinación de teclas 'Alt + R' importen el render ya realizado de
un 'Write' node seleccionado como un nuevo 'Read' node. Útil para fácil y rápidamente
traer a Nuke renders recién hechos para revisión u otros fines. Requiere exactamente
un 'Write' node seleccionado para correr apropiadamente.

Para usarlo se puede presionar la combinación de teclas 'Alt + R' mientras se está
trabajando en el Node Graph, o bien hacer click derecho en el Node Graph y hacer
click en la opción 'Import Render'.

Si no hay ningún nodo seleccionado, este comando no hará nada. Si hay más de un nodo
seleccionado o el nodo seleccionado no es un 'Write', se mostrará un mensaje
indicando la razón del error. De la misma forma, si la ruta del 'Write' node
seleccionado está vacía, no es válida o aún no se ha realizado el render, aparecerá
un mensaje indicando la razón del error.

## Instalación

Copiar la carpeta 'ImportRender' dentro del directorio .nuke sin realizar ningún
cambio. Además, copiar la siguiente línea de código Python al final del archivo
.nuke/init.py

```python
nuke.pluginAddPath('./ImportRender')
```

Para que la instalación surta efecto es necesario cerrar todas las instancias de
Nuke y volver a abrir.

