# UpdateTools

Herramienta para actualizar automáticamente las PanoTools a su última version.

