# UpdateTools

Herramienta para actualizar automáticamente las PanoTools a su última version.

## Uso

Para usar esta herramienta basta con ir a 'PanoTools' en la barra de herramientas
superior en Nuke y luego dar click en 'Update Tools'. Si todo sale bien, aparecerá
un mensaje indicando que las PanoTools fueron actualizadas satisfactoriamente,
señalándo la versión a la que se ha actualizado.

Nota: esta herramienta requiere conexión a internet desde la aplicación de Nuke.

## Instalación

Nota: instalar esta herramienta manualmente no tiene mucho sentido, ya que sirve
para actualizar las PanoTools. Se recomienda instalar con el paquete completo de
PanoTools en vez de instalar específica y manualmente.

Copiar la carpeta 'UpdateTools' dentro del directorio .nuke sin realizar ningún
cambio. Además, copiar la siguiente línea de código Python al final del archivo
.nuke/init.py

```python
nuke.pluginAddPath('UpdateTools')
```

Para que la instalación surta efecto es necesario cerrar todas las instancias de
Nuke y volver a abrir.

