import UpdateTools
nuke.menu('Nuke').addCommand('PanoTools/Update Tools', 'UpdateTools.UpdateTools()')
