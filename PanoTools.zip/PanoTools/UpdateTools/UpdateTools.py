# Written by Eugenio Arteaga A. at Panolab spa

import nuke
import sys
import os
import zipfile

NUKEPATH = os.path.join(os.path.expanduser('~'), '.nuke')

def download_file(url, path):
    with requests.get(url, stream=True) as r:
        r.raise_for_status()
        with open(path, 'wb') as f:
            for chunk in r.iter_content(chunk_size=8192): 
                f.write(chunk)

def UpdateTools():


