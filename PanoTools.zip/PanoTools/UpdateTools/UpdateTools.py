# Written by Eugenio Arteaga A. at Panolab spa

import nuke
import os
import zipfile

LINK = 'https://github.com/Panolab/PanoToolsRelease/raw/main/PanoTools.zip'
NUKEPATH = os.path.join(os.path.expanduser('~'), '.nuke')

def download_file(url, path):
    with requests.get(url, stream=True) as r:
        r.raise_for_status()
        with open(path, 'wb') as f:
            for chunk in r.iter_content(chunk_size=8192): 
                f.write(chunk)

def unzip_file(zippath, dirpath):
    with zipfile.ZipFile(zippath, 'r') as zipfile:
        zipfile.extractall(dirpath)

def panotools_version(file):
    fp = open(file, 'r')
    version = ''
    for i, line in enumerate(fp):
        if i == 2:
            version = line
            break
    fp.close()
    return version

def UpdateTools():
    zipname = os.path.basename(LINK)
    zippath = os.path.join(NUKEPATH, zipname)
    download_file(LINK, zippath)
    unzip_file(zippath, NUKEPATH)
    panotools_version(os.path.join(NUKEPATH, 'PanoTools', 'README.md')
    nuke.message('Succesfully updated PanoTools to version: {}'.format(version))

