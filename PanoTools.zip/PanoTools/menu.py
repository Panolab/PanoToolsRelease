from ChangeColorSpace import ChangeColorSpace
from ImportRender import ImportRender
from LutDownload import LutDownload
from LutViewer import LutViewer
from PathGenerator import PathGenerator
from ProjectGenerator import ProjectGenerator
from PublishVersion import PublishVersion
from ShowFolder import ShowFolder
from StartAt import StartAt
from UpdateTools import UpdateTools
from VersionDownload import VersionDownload

nuke.menu('Nuke').addCommand('PanoTools/Change Color Space', 'ChangeColorSpace.ChangeColorSpace()')
nuke.menu('Nuke').addCommand('PanoTools/Start At', 'StartAt.StartAt()')
nuke.menu('Nuke').addCommand('PanoTools/Path Generator', 'PathGenerator.PathGenerator()')
nuke.menu('Nuke').addCommand('PanoTools/Project Generator', 'ProjectGenerator.ProjectGenerator()')
nuke.menu('Nuke').addCommand('PanoTools/Download Lut', 'LutDownload.LutDownload()')
nuke.menu('Nuke').addCommand('PanoTools/Download Version', 'VersionDownload.VersionDownload()')
nuke.menu('Nuke').addCommand('PanoTools/Publish Version', 'PublishVersion.PublishVersion()')
nuke.menu('Nuke').addCommand('PanoTools/Update Tools', 'UpdateTools.UpdateTools()')
nuke.menu('Node Graph').addCommand('Import Render', 'ImportRender.ImportRender()', 'alt+r')
nuke.menu('Node Graph').addCommand('Show Folder', 'ShowFolder.ShowFolder()', 'alt+o')
nuke.menu('Viewer').addCommand('Change Lut', 'LutViewer.LutViewer()', 'alt+p')

