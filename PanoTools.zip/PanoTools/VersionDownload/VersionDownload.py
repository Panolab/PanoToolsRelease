# Written by Eugenio Arteaga at Panolab spa

import nuke
import nukescripts
import os
import sys

FKEY = '.ftrack_key'
FSERVER = 'https://panolab.ftrackapp.com'
HOMEPATH = os.path.expanduser('~')
NUKEPATH = os.path.join(HOMEPATH, '.nuke')

sys.path.append(os.path.join(NUKEPATH, 'PanoTools', 'PanoModules'))
import requests
import ftrack_api

class FkeyPanel(nukescripts.PythonPanel):
    def __init__(self):
        nukescripts.PythonPanel.__init__(self, 'Ftrack Key')
        self.mailKnob = nuke.String_Knob('mail', 'Mail:')
        self.keyKnob = nuke.String_Knob('key', 'Ftrack Key:')
        self.addKnob(self.mailKnob)
        self.addKnob(self.keyKnob)

class VersionDownloadPanel(nukescripts.PythonPanel):
    def __init__(self):
        nukescripts.PythonPanel.__init__(self, 'Download Ftrack Version')
        self.pathKnob = nuke.File_Knob('path', 'Save in:')
        self.shotsKnob = nuke.String_Knob('shot', 'Shot:')
        self.pathKnob.setValue('../RENDERS/MOV/')
        self.addKnob(self.pathKnob)
        self.addKnob(self.shotsKnob)

class VersionDownloadChooserPanel(nukescripts.PythonPanel):
    def __init__(self, assets_list):
        nukescripts.PythonPanel.__init__(self, 'Choose Ftrack Asset')
        self.assetKnobs = []
        for i in range(len(assets_list)):
            if len(assets_list[i]) == 0:
                continue
            nmax = assets_list[i][0]['name'] + ' v000'
            names = []
            vmax = 0
            for asset in assets_list[i]:
                for version in asset['versions']:
                    v = version['version']
                    name = asset['name'] + ' v{:03d}'.format(v)
                    names.append(name)
                    if '_cop' not in name and '_COP' not in name and v > vmax:
                        vmax = v
                        nmax = name
            names = sorted(names)
            index = '{:02d}'.format(i + 1)
            name = '_'.join(names[0].split('_')[:3])
            assetKnob = nuke.Enumeration_Knob('asset' + index, name, names)
            assetKnob.setValue(nmax)
            self.addKnob(assetKnob)
            self.assetKnobs.append(assetKnob)

def write_fkey_file(path, mail, fkey):
    file = open(path, 'w')
    file.writelines([mail + '\n', fkey])
    file.close()

def read_fkey_file(path):
    with open(path) as file:
        lines = [line.rstrip() for line in file]
    return lines

def download_file(url, path):
    with requests.get(url, stream=True) as r:
        r.raise_for_status()
        with open(path, 'wb') as f:
            for chunk in r.iter_content(chunk_size=8192): 
                f.write(chunk)

def ftrack_connect():
    fkey_path = os.path.join(NUKEPATH, FKEY)
    while not os.path.exists(fkey_path):
        panel = FkeyPanel()
        if panel.showModalDialog():
            mail = panel.mailKnob.value().strip()
            fkey = panel.keyKnob.value().strip()
            write_fkey_file(fkey_path, mail, fkey)
        else: return None
    fkey_lines = read_fkey_file(fkey_path)
    mail = fkey_lines[0]
    fkey = fkey_lines[1]
    try: session = ftrack_api.Session(server_url=FSERVER, api_key=fkey, api_user=mail)
    except: session = None
    return session

def shots_parse(expr):
    shots = expr.replace(' ', '').split(',')
    for shot in shots:
        if '-' in shot:
            shots.remove(shot)
            shotrange = shot.split('-')
            if len(shotrange) != 2:
                nuke.message('Invalid expression for shots range: ' + expr)
                return None
            shotname = '_'.join(shotrange[0].split('_')[:-1])
            start, end = shotrange[0].split('_')[-1], shotrange[1].split('_')[-1]
            if int(start) > int(end):
                nuke.message('Invalid range for shots expression: ' + expr)
                return None
            for i in range(int(start), int(end) + 1):
                shots.append(shotname + '_{:04d}'.format(i))
    return sorted(shots)

def shotsget(session, expr):
    ret = []
    shots = shots_parse(expr)
    if shots == None or len(shots) == 0:
        return shots

    first = '_'.join(shots[0].split('_')[:-1]) + '_'
    queried = session.query('select name from Shot where name like "{}%"'.format(first))
    for shot in shots:
        for q in queried:
            if shot == q['name']:
                ret.append(shot)
    return ret

def version_download(path, shotexpr):
    if not path or len(path) == 0:
        nuke.message('Path field for destination to save the shot cannot be empty')
        return
    elif path[0] == '.':
        scriptdir = nuke.script_directory()
        if len(scriptdir) == 0:
            nuke.message(
                'Cannot use relative path if you have not saved your project: {}'
                .format(path)
            )
            return
        path = os.path.join(scriptdir, path)
    if not shotexpr or len(shotexpr) == 0:
        try:
            scriptname = nuke.scriptName()
        except:
            nuke.message(
                'Cannot leave blank Shot field if you have not saved your project'
            )
            return
        shotexpr = '_'.join(os.path.basename(scriptname).split('_')[:3])

    session = ftrack_connect()
    if session == None:
        nuke.message('Could not connect to Ftrack')
        return
 
    shots = shotsget(session, shotexpr)
    if shots == None:
        return
    if len(shots) == 0:
        nuke.message('Could not find any shots in Ftrack for expression: ' + shotexpr)
        session.close()
        return

    all_assets, assets_list = [], []
    qassets = session.query(
        'select name, versions from Asset where name like "{}%"'
        .format('_'.join(shots[0].split('_')[:1]) + '_')
    )

    mapassets = {}
    for qa in qassets:
        keyshot = '_'.join(qa['name'].split('_')[:3])
        if keyshot in mapassets:
            mapassets[keyshot].append(qa)
        else:
            mapassets[keyshot] = [qa]

    for shot in shots:
        assets = mapassets[shot] if shot in mapassets else []
        assets_list.append(assets)
        all_assets += assets

    if len(all_assets) == 0 or len(assets_list) == 0:
        nuke.message('Could not find assets on Ftrack for the specified shots')
        session.close    

    errors = []
    panel = VersionDownloadChooserPanel(assets_list)
    if panel.showModalDialog():
        if not os.path.exists(path):
            os.makedirs(path)

        for knob in panel.assetKnobs:
            vernode, component, filetype = None, None, None
            assetname, verint = knob.value().split(' ')
            verint = int(verint[1:])
            for a in all_assets:
                if a['name'] == assetname:
                    for v in a['versions']:
                        if int(v['version']) == verint:
                            vernode = v
                            break
                    break

            if vernode == None:
                errors.append('Could not find the asset: ' + assetname)
                continue

            components = vernode['components']
            for comp in components:
                ft = comp['file_type']
                if ft.lower() == '.mp4':
                    filetype = ft
                    component = comp
                elif ft.lower() == '.mov':
                    filetype = ft
                    component = comp
                    break
            
            if component == None or filetype == None:
                errors.append(
                    'Could not find asset {} with format .mov or .mp4'
                    .format(assetname)
                )
                continue

            filename = assetname + '_v{:03d}'.format(vernode['version']) + filetype
            fpath = os.path.join(path, filename) 
            location = component['component_locations'][0]
            url = location['url']['value']

            if not os.path.exists(fpath):
                download_file(url, fpath)
            
            r = nuke.createNode('Read')
            r['file'].fromUserText(fpath.replace('\\', '/'))

    if len(errors) > 0:
        nuke.message('\n'.join(errors))
    session.close()

def VersionDownload(): 
    panel = VersionDownloadPanel()
    if panel.showModalDialog():
        path = panel.pathKnob.value()
        shots = panel.shotsKnob.value()
        version_download(path, shots)

