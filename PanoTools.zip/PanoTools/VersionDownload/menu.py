import VersionDownload
nuke.menu('Nuke').addCommand('PanoTools/Download Version', 'VersionDownload.DownloadVersion()')
