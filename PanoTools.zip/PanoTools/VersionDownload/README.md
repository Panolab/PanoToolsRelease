# VersionDownload

Descarga las últimas versiones de tus planos desde Ftrack a Nuke en un solo click.
Ya sea el plano que estás trabajando, o toda una secuencia de planos, y en las
versiones que tú quieras, descarga tus revisores de forma rápida y fácil sin salir
de Nuke.

# Ftrack

Solo si es la primera vez que usas esta herramienta, aparecerá una ventana especial
titulada 'Ftrack Key'. Esta ventana presenta dos campos a llenar, uno para el mail
y el otro para la Ftrack API Key. En el primer campo debes escribir el mail bajo el
cual tengas tu cuenta de Ftrack.

La llave de Ftrack a poner en el segundo campo debes buscarla directamente en un navegador,
dentro de la plataforma de Ftrack. Una vez en la plataforma, presionar en el ícono
de tu cuenta en la esquina superior derecha. Luego, en el menú desplegable ir a 'My
Account'. Una vez en las configuraciones de tu cuenta, presionar 'Security settings'
en el menu lateral izquierdo. Por último, ir al cuadro 'Personal API key' y generar
tu llave personal de Ftrack.

Una vez generada la llave, copiarla y pegarla en el campo 'Ftrack Key' y apretar Ok.
Esto generará un archivo escondido dentro de tu carpeta .nuke llamado .ftrack_key
donde se guardará esta información para no tener que preguntar estos datos cada vez
que se usa la herramienta.

Nota: En Ftrack puedes generar tu llave tantas veces como quieras, pero solo puedes 
verla en una ocasión, por lo que se recomienda guardar la llave en un lugar seguro.

## Uso

Para usar la herramienta solo basta ir a 'PanoTools' en la barra superior de Nuke,
y presionar la opción 'Version Download'. Esto abrirá una ventana con dos campos. El
primer campo es un seleccionador de directorios para indicar donde se desea guardar
la media a descargar en tu sistema. La rutas pueden ser absolutas o relativas. Si la
ruta es relativa, el proyecto de Nuke debe haber sido guardado, o aparecerá un error
indicando que no se puede establecer una ruta relativa si no se ha guardado el
script.

El segundo campo sirve para especificar qué plano o planos se quiere descargar. Este
campo se puede dejar vacío, en cuyo caso la herramienta utilizará el nombre del
proyecto de Nuke para buscar ese plano en Ftrack. En este caso, si no se ha guardado
el proyecto aparecerá un error indicando que se debe guardar para esta
funcionalidad. De la misma forma, el proyecto debe haber sido guardado con
exactamente la misma nomenclatúra estándar como han sido nombrados los planos en 
Ftrack.

Por otro lado, en este segundo campo se puede especificar un plano escribiéndo el
nombre del plano según la nomenclatura estándar. De la misma forma, se puede
especificar más de un plano, separándo los nombres de los planos con comas ",",
o bien se puede indicar todo un rango de planos utilizando un guion simple "-". Esto
seleccionará todos los planos existentes en la plataforma de Ftrack dentro del rango
de numeración indicado.

Luego de presionar Ok, la herramienta buscará los planos deseados en Ftrack, lo que
puede tardar algunos segundos según la conexión a internet. Si no se encuentra
ningún plano dentro de la expresión ingresada aparecerá un error indicando la razón.

Al cabo de unos segundos aparecerá una segunda ventana. Esta ventana mostrará todos
los planos encontrados en Ftrack que corresponden a la expresión puesta en la
primera ventana. Por cada plano encontrado se presentará una lista de assets
disponibles para descargar. Por cada plano se debe seleccionar el asset y versión
que se desea descargar. Por defecto vendrá seleccionado el asset de tarea de
composición en su última versión disponible en Ftrack.

Luego de presionar Ok los assets señalados comenzarán a descargarse. Esto puede
tardar varios segundos dependiendo de la conexión a internet. Al terminar el proceso
se importarán todos los assets descargados al proyecto de Nuke, listos para ser
visualizados y revisados.

## Instalación

Copiar la carpeta 'VersionDownoad' dentro del directorio .nuke sin realizar ningún
cambio. Además, copiar la siguiente línea de código Python al final del archivo
.nuke/init.py

```python
nuke.pluginAddPath('VersionDownload')
```

Para que la instalación surta efecto es necesario cerrar todas las instancias de
Nuke y volver a abrir.

