# Written by Eugenio Arteaga at Panolab spa

import nuke
import sys
import os

sys.path.append(os.path.join(os.path.expanduser('~'), '.nuke', 'PanoTools', 'PanoModules'))
import requests

def download_file(url, path):
    with requests.get(url, stream=True) as r:
        r.raise_for_status()
        with open(path, 'wb') as f:
            for chunk in r.iter_content(chunk_size=8192): 
                f.write(chunk)

def LutDownload():
    url = 'https://raw.githubusercontent.com/Panolab/BBLuts/main/BBLuts/'
    name = os.path.basename(nuke.scriptName())
    lutname = '_'.join(name.split('_')[:3]) + '_LUT.cube'
    luturl = url + lutname
    path = os.path.join(os.path.dirname(nuke.script_directory()), 'ASSETS', 'LUTS')
    if not os.path.exists(path):
        os.makedirs(path)

    message = 'Successfully linked file: '
    lutpath = os.path.join(path, lutname)
    if not os.path.exists(lutpath):
        download_file(luturl, lutpath)
        message = 'Successfully downloaded and linked file: '
    
    nodes = nuke.allNodes(recurseGroups=True)
    for n in nodes:
        if n.Class() == 'OCIOFileTransform':
            n['file'].setValue(lutpath.replace('\\', '/'))
 
    nuke.message(message + lutpath)

