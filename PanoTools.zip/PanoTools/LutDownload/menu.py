import LutDownload
nuke.menu('Nuke').addCommand('PanoTools/Download Lut', 'LutDownload.LutDownload()')
